# Jeffrey Haire
# IT FDN 100
# Prof Root
# Assignment 6
# 11/6/17

# Because the file doesn't exist on your computer, I have to make it like assgn 3
def WriteListFirst(file, list):
    """This function writes a text file list"""
    objF = open(file, "w")
    objF.write(list)
    objF.close()
WriteListFirst("c:\PythonClass\Module05\ToDo.txt","Task,Priority \nClean, Low\nPay Bills, High")

# Read from the text file
objFile = open("C:\PythonClass\Module05\ToDo.txt", "r")
strData = objFile.readline()
dicRow1 = {(strData.split(",")[0]).strip():(strData.split(",")[1]).strip()}
lstTable = [dicRow1]
for line in objFile:
 strData = line
 dicRow = {(strData.split(",")[0]).strip(): (strData.split(",")[1]).strip()}
 lstTable.append(dicRow),
objFile.close()

def Display():
    """This function displays the list to the user"""
    for row in lstTable:
        print(row)
def Add():
    """This function lets a user add items to the list"""
    strTask = input("What task do you want to add to the list?: ")
    strPriority = input(str("What priority level is it?: "))
    dicRow = {strTask: strPriority}
    lstTable.append(dicRow)
def Remove():
    """This function lets a user remove items from the list"""
    strData = input("What term do you want me to delete?: ")
    for row in lstTable:
        if strData in row:
            lstTable.remove(row)
            print("\nOkay, I deleted", strData)
def Save():
    """This functions lets the user save their list to text file"""
    strSaveToFile = input("Type 'yes' to save to text file or any key to exit: ")
    if (strSaveToFile.lower() == "yes"):
        objF = open("c:\PythonClass\Module05\ToDo.txt", "w")
        objF.write(str(lstTable))
        objF.close()
        print("The following data was saved to a file:\n\r", lstTable)
def Menu():
    """This functions lays out a functioning menu"""
    choice = None
    while choice != "0":
        print(
            """
            Please select one of the following options:
    
            0 - Quit
            1 - Show all tasks and priority levels
            2 - Add a task and priority level for it
            3 - Remove an existing item
            4 - Save to text file
            """
        )
        choice = input("Choice: ")
        print()

        if choice == "0":
            print("Good-bye.")
            break

        elif choice == "1":
            print("Here are your current tasks and priority levels\n")
            Display()
        elif choice == "2":
            Add()
            continue

        elif choice == "3":
            Remove()
        elif choice == "4":
            Save()

        else:
            print("Continue")
def SaveToText():
    """This function saves the list to text upon closing"""
    objF = open("c:\PythonClass\Module05\ToDo.txt", "w")
    objF.write(str(lstTable))
    objF.close()
    print("The following data was saved to a file:\n\r", lstTable)


def ExitPauseMsg():
    """This function pauses until the user hits a key, then exits."""
    input("\n\nPress the enter key to exit.")


Menu()
SaveToText()
ExitPauseMsg()